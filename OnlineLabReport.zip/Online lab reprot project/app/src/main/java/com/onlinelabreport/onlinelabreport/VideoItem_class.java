package com.onlinelabreport.onlinelabreport;

public class VideoItem_class {
        private String videoUrl;
        private String description;

        public VideoItem_class(String videoUrl, String description) {
            this.videoUrl = videoUrl;
            this.description = description;
        }

        public String getVideoUrl() {
            return videoUrl;
        }

        public String getDescription() {
            return description;
        }


}
