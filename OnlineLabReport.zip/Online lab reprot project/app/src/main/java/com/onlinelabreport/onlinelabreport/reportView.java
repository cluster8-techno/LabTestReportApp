package com.onlinelabreport.onlinelabreport;

import android.Manifest;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class reportView extends AppCompatActivity {

    private static final int REQUEST_STORAGE_PERMISSION = 1;

    private EditText editTextUrl;
    private Button btnDownload ;
    FloatingActionButton btnBack;
    private TextView textViewProgress;

    private long downloadId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_view);

        editTextUrl = findViewById(R.id.pdfUrl);
        btnDownload = findViewById(R.id.btnDownload);
        textViewProgress = findViewById(R.id.textViewProgress);
        btnBack = findViewById(R.id.backHomeBtn1);


        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermissionAndDownload();
            }
        });

       btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(reportView.this, HomeActivity.class);
                startActivity(intent);
            }
        });

    }

    private void checkPermissionAndDownload() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_STORAGE_PERMISSION);
            } else {
                startDownload();
            }
        } else {
            startDownload();
        }
    }

    private void startDownload() {
        String url = editTextUrl.getText().toString();

        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setTitle("File Download");
        request.setDescription("Downloading file...");

        // Change the destination directory if needed
        request.setDestinationInExternalPublicDir(
                "/Download", "downloaded_file");

        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        downloadId = downloadManager.enqueue(request);

        registerReceiver(new DownloadCompleteReceiver(),
                new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }

    private class DownloadCompleteReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
            if (id == downloadId) {
                textViewProgress.setText("Download Complete");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startDownload();
            }
        }
    }
}